from calendar import isleap


# calcular si es un año bisiesto
def anio_bisiesto(anio):
    if isleap(anio):
        return True
    else:
        return False
