public class Termostato {

    private int sensado;
    private int panel;
    
    // Método de inicialización
    public Termostato(s, p){
        // Atributos de instancia
        this.sensado = s;
        this.panel = p;
    }

    // Comandos
    public void establecerSensado(s){
        this.sensado = s;
    }

    public void establecerPanel(p){
        this.panel = p;
    }

    // Consultas
    public int obtenerSensado(){
        return this.sensado
    }

    public int obtenerPanel(){
        return this.panel
    }

    public boolean regulado(){
        return this.sensado == this.panel
    }
}
