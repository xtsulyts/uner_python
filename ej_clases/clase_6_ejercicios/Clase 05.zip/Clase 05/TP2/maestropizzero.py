class MaestroPizzero:
    pass