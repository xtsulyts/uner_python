from mozo import Mozo
from maestropizzero import MaestroPizzero

class TesterPizzeria:
    def main(self):
        # Solución de los puntos 5.a., 5.b, 5.c, ...
        mozo1 = Mozo('Alfredo')

if __name__ == '__main__':
    testerPizzeria = TesterPizzeria()
    testerPizzeria.main()