##### ESTRUCTURAS DE CONTROL #####

"""7. Que imprima todos los números entre el 100 y el 199."""

print("")
print("##### EJERCICIO 7 #####")
print("")


#Funcion para imprimir los numeros.
def iprecion_numeros():
    for imprecion in range(102, 200):#Defino el rango de imprecion solicitado guardandolo en una veriable, inicio 101 y fin 199.
        imprecion = imprecion - 1
        print(imprecion)
        print(f"{imprecion}")#Imprecion del resultado.

iprecion_numeros()

print("")
print("##### FIN DEL PROGRAMA #####")