# En este repositorio fuy trabajando el tp_2, lo hice en una netbbok con distribucion fedora
# en mi laburo y cuando tenia tiempo muerto en la calle 
# y en desktop window 11 en mi casa.

##### https://github.com/xtsulyts/uner_python.git #####